import zoo as menagerie
menagerie.hours()

from zoo import hours
hours()